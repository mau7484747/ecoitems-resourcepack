MAU SPEZIALPAPIER – CustomModelData 1001
Minecraft Java Edition 1.21.11

ENTHALTEN
- Eigene Papier-Textur (Parchment mit rotem Siegel)
- Item-Model-Zuordnung für Papier mit CustomModelData 1001
- Normales Papier bleibt unverändert, wenn kein passender Wert gesetzt ist

TESTBEFEHL (als OP / mit passenden Rechten):
/give @p minecraft:paper[minecraft:custom_model_data={floats:[1001.0]}] 1

WICHTIG FÜR DEN SERVER
Dieses ZIP ist das RESOURCE-PACK (Optik). Es ändert nicht automatisch vorhandene Items
und vergibt auch keine CustomModelData. Das Item muss mit dem obigen Befehl oder über
dein Plugin/Skript mit CustomModelData 1001 erstellt werden.

SERVER-RESOURCE-PACK
Lade diese ZIP-Datei auf einen direkten HTTPS-Download-Link hoch und trage den Link
in server.properties bei resource-pack= ein. Spieler müssen das Pack dann annehmen.

Hinweis: Andere Resource-Packs, die ebenfalls assets/minecraft/items/paper.json ändern,
können mit dieser Zuordnung kollidieren.
