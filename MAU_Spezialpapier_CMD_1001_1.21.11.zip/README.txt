MAU WINTER WINGS - Minecraft Java 1.21.11
Give: /give @p minecraft:netherite_horse_armor 1
The built-in netherite_horse_armor item definition directly selects the custom winter_wings model.
Custom 3D feather shape, icy blue/white/silver texture and falling snow animation.
No drill model or drill override is included.
