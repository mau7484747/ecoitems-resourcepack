MAU PURPLE SWORD – Minecraft Java 1.21.11

Item: MAU Purple Sword
Basis-Item: minecraft:netherite_sword
Custom Model Data: 1001
Befehl: /give @p minecraft:netherite_sword[minecraft:custom_model_data={floats:[1001.0]}] 1

Die violette Klinge hat eine animierte Textur mit pulsierendem Leuchten und bewegten lila Partikeln.
Normale Netherite-Schwerter bleiben unverändert.
