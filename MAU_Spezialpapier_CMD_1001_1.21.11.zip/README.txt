MAU WINTER WINGS - Minecraft Java 1.21.11
Custom item model ID: minecraft:custom/elitecreatures/volt_wings/winter_wings
Give: /give @p minecraft:netherite_horse_armor[minecraft:item_model="minecraft:custom/elitecreatures/volt_wings/winter_wings"] 1
Winter Wings use their own item definition and a separate custom 3D model.
Animated icy blue/white texture with falling snowflakes.
No drill files are included.
