MAU RESOURCE PACK – Minecraft Java 1.21.11

ITEM 1: MAU Spezialpapier
Basis-Item: minecraft:paper
Custom Model Data: 1001
Befehl: /give @p minecraft:paper[minecraft:custom_model_data={floats:[1001.0]}] 1

ITEM 2: MAU Purple Crystal (eigenes dekoratives 3D-Modell)
Basis-Item: minecraft:amethyst_shard
Custom Model Data: 1002
Befehl: /give @p minecraft:amethyst_shard[minecraft:custom_model_data={floats:[1002.0]}] 1

Das Pack enthält ein originales, dekoratives Kristallmodell mit eigener Pixeltextur.
Normales Papier und normale Amethystscherben bleiben ohne den passenden CMD-Wert unverändert.

Server: ZIP unverändert auf einen direkten HTTPS-Link hochladen und als Resource-Pack setzen.
