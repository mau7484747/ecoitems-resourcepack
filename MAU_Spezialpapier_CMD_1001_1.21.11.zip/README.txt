MAU WINTER WINGS - Minecraft 1.21.11
CMD: Netherite Horse Armor 1002
Icy blue, white and silver texture with animated falling snowflakes.
Existing model and left/right-hand display transforms preserved.
No drill model or drill override is included.
