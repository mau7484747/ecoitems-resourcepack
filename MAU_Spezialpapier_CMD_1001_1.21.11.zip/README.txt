MAU WINTER WINGS - Minecraft Java 1.21.11
Basis-Item: minecraft:netherite_pickaxe
Custom Model Data: 1001
Befehl: /give @p minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[1001.0]}] 1
Pack neu laden: F3+T
Item-Zuordnung aus dem MAUTEXTURE-Basispack beibehalten (nur Modell-Ziel auf Volt Wings ge�ndert).
Originales Volt-Wings-Modell und Original-Displaytransformationen unver�ndert �bernommen.
Originale volt_wings.png als Vorlage; Winterfarben und animierte Schneeflocken hinzugef�gt.
Kein Bohrer-Modell und keine Bohrer-Texturen enthalten.

Blitztruhe: model bounds corrected; purple black hole and energy streaks.
