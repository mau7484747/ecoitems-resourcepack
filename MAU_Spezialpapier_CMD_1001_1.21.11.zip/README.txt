MAU VOLT WINTER WINGS - Minecraft Java 1.21.11
Basis-Item: minecraft:netherite_horse_armor
Custom Model Data: 1002
Befehl: /give @p minecraft:netherite_horse_armor[minecraft:custom_model_data={floats:[1002.0]}] 1
Pack neu laden: F3+T
Originales Volt-Wings-Modell, Original-UVs, Original-Item-Zuordnung und Original-Handtransformationen beibehalten.
Nur die Textur wurde eisblau/weiss umgef�rbt und um fallende Schneeflocken animiert.
