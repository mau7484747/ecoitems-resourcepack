MAU OP DRILL – Minecraft Java 1.21.11
Basis-Item: minecraft:netherite_pickaxe
Custom Model Data: 1001
/give @p minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[1001.0]}] 1
