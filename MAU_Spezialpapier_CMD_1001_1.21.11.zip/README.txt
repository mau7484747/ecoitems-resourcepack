MAU WINTER WINGS - Minecraft 1.21.11
CMD: Netherite Horse Armor 1002
New custom feather model with an original icy blue/white/silver texture.
Animated falling snow crystals: 8 frames.
Offhand third-person uses the existing left-hand/back transform; main hand keeps its separate compact right-hand transform.
No drill model or drill override is included.
