MAUSMP - WEIHNACHTSKISTE 3D-UPGRADE

Dieses Overlay enthaelt das verbesserte Weihnachtskisten-Modell und neue Detailtexturen.
Es benoetigt das MAUSMP Weihnachtskisten-HD-Textur-Overlay als darunterliegendes Pack.
Die Blitzkiste ist nicht enthalten und wird nicht veraendert.

Installation:
1. ZIP in resourcepacks legen.
2. Dieses 3D-Upgrade ueber dem Weihnachtskisten-HD-Textur-Overlay aktivieren.
3. Mit F3+T neu laden.
