MAUSMP - WEIHNACHTSKISTE REALISTIC UPGRADE

Dieses ist ein einziges, vollstaendiges Weihnachtskisten-Upgrade.
Es enthaelt das neue Modell, den neuen Material-Atlas sowie die verbesserten Oberflaechen-
Texturen fuer die Weihnachtskiste. Das Modell hat neue Rentiere, Schlitten, Laternen und
einen geschlossenen Innenboden direkt unter dem Weg.

INSTALLATION:
1. Dieses ZIP in den Minecraft-Ordner resourcepacks legen.
2. Ueber dem normalen MAUSMP-Haupt-Resourcepack aktivieren.
3. Die alten Weihnachtskisten-HD-, 3D-HD- und Modell-Fix-Overlays deaktivieren.
4. Mit F3+T neu laden.

Die Blitzkiste ist nicht enthalten und wird nicht veraendert.
