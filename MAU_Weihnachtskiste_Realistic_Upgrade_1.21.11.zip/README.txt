MAUSMP - WEIHNACHTSKISTE REALISTIC UPGRADE

Ein einziges, vollstaendiges Weihnachtskisten-Upgrade.
Enthaelt das korrigierte Modell, den hochaufloesenden Material-Atlas und verbesserte
Oberflaechentexturen. Die Blitzkiste ist nicht enthalten und bleibt unveraendert.

Installation:
1. ZIP in resourcepacks legen.
2. Ueber dem normalen MAUSMP-Haupt-Resourcepack aktivieren.
3. Alte Weihnachtskisten-HD-, 3D-HD- und Modell-Fix-Overlays deaktivieren.
4. Mit F3+T neu laden.
