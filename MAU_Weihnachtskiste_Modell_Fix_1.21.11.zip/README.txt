MAUSMP - WEIHNACHTSKISTE MODELL-FIX

Dieses kleine Overlay ersetzt nur double_chest.json.
Es schliesst den kompletten Boden unter Strasse und Seitenflaechen und baut die Rentiere
mit zusammenhaengendem Koerper, Hals, Kopf, Beinen, Hufen und Geweih neu auf.

WICHTIG: Die vorherige MAU_Weihnachtskiste_3D_HD_Overlay ZIP muss darunter aktiviert bleiben,
damit die Detailtexturen fuer Laternen, Geschirr, Geweih und Geschenke verfuegbar sind.
Das Weihnachtskisten-HD-Textur-Overlay bleibt darunter ebenfalls aktiviert.
Die Blitzkiste ist nicht enthalten.
