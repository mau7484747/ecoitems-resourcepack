MAUSMP - WEIHNACHTSKISTE HD TEXTUR-OVERLAY

This overlay improves only the Christmas crate textures.
The Blitzkiste, double_chest.json, model geometry, size, UV mapping and crate layout are unchanged.

Installation:
1. Put this ZIP into the Minecraft resourcepacks folder.
2. Enable it ABOVE the existing MAUSMP resource pack.
3. Reload resource packs with F3+T.

Only Christmas crate textures and their animation metadata are included.
